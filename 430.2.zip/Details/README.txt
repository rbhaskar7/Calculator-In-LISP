Name: 			Abhirukth Kumar Chakravarthy
Roll no: 		CSE/19003/430
Reg no.: 		430


				+-------------------------------------------------------+
				|							|
				| <<<<----- Simple LISP basic ASMD calculator ----->>>> |
				|							|
				+-------------------------------------------------------+

Program details : 	This particular program represents a simple basic calculator i.e., +(addition), -(subtraction), 
			*(multiplication), and /(division) which takes operator code as input, which are as follows:

			1 for +
			2 for -
			3 for *
			4 for /

			After this it also asks for additional two numbers as input in separate new lines on which the 
			particular operation will be executed.

			The output will be displayed after executing the code.


Sample input :		3	// operation type (multiplication)
			23	// first number
			41	// second number

Sample output :		Your entered choice is: 3		// v.i.z., multiplication
			Your entered numbers are: 23 and 41
			Product: 943				// result
			